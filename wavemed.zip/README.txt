Passos para Usar MultiWaveMed

1- Menu File (Open) image query
2- Selecionar o tipo de wavelets (parametros)
3- Colocar em FEature Vector Files
d:\Programas\Sltree\cesar\gaborfeatures5631-26.txt
4- Selecionar botao (Search Similar Images)


Acknowledgments. The authors are grateful to the Center of Image Science of the Clinical Hospital of the University of S�o Paulo at Ribeir�o Preto - Brazil, which kindly provided the project with the images used in the experiments.