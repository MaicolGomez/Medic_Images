//---------------------------------------------------------------------------

#ifndef AuxiliarH
#define AuxiliarH
//---------------------------------------------------------------------------
int iNroFeatures = 9;
double *VetorCaracteristica;
#endif
 